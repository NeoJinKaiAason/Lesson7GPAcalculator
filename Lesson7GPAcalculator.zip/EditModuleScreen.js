import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function EditModuleScreen({ route, navigation }) {
    const { module, modulesData, setModulesData } = route.params;

    const [moduleName, setModuleName] = useState(module.name);
    const [moduleGrade, setModuleGrade] = useState(module.grade);
    const [moduleCredit, setModuleCredit] = useState(String(module.credit));

    const saveChanges = () => {
        if (!moduleName || !moduleGrade || !moduleCredit) {
            alert('Please fill in all fields.');
            return;
        }

        const updatedModules = modulesData.map((mod) =>
            mod.id === module.id
                ? { ...mod, name: moduleName, grade: moduleGrade, credit: parseInt(moduleCredit, 10) }
                : mod
        );

        setModulesData(updatedModules);
        navigation.goBack(); // Return to HomeScreen
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Edit Module</Text>
            <TextInput
                style={styles.input}
                placeholder="Module Name"
                value={moduleName}
                onChangeText={setModuleName}
            />
            <TextInput
                style={styles.input}
                placeholder="Grade (e.g., A, B+, etc.)"
                value={moduleGrade}
                onChangeText={setModuleGrade}
            />
            <TextInput
                style={styles.input}
                placeholder="Credits"
                keyboardType="numeric"
                value={moduleCredit}
                onChangeText={setModuleCredit}
            />
            <Button title="Save Changes" onPress={saveChanges} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        padding: 10,
        marginBottom: 15,
        backgroundColor: '#fff',
    },
});
