import React, { useState } from 'react';
import { View, Text, FlatList, Button, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import modules from './data';

export default function HomeScreen({ navigation }) {
    const [modulesData, setModulesData] = useState(modules);

    // GPA Calculation Function
    const calculateGPA = (modulesData) => {
        const totalCredits = modulesData.reduce((acc, module) => acc + module.credit, 0);
        const weightedGrades = modulesData.reduce((acc, module) => {
            let gradePoints = 0;

            // Convert letter grade to grade points (example for common GPA scales)
            switch (module.grade) {
                case 'A': gradePoints = 4.0; break;
                case 'B+': gradePoints = 3.5; break;
                case 'B': gradePoints = 3.0; break;
                case 'C+': gradePoints = 2.5; break;
                case 'C': gradePoints = 2.0; break;
                case 'D': gradePoints = 1.0; break;
                case 'F': gradePoints = 0.0; break;
                default: gradePoints = 0.0;
            }

            return acc + gradePoints * module.credit;
        }, 0);

        const gpa = totalCredits > 0 ? weightedGrades / totalCredits : 0.0;
        return gpa.toFixed(2); // Return GPA rounded to 2 decimal places
    };

    // Function to delete a module
    const deleteModule = (id) => {
        Alert.alert(
            'Delete Module',
            'Are you sure you want to delete this module?',
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete',
                    style: 'destructive',
                    onPress: () => {
                        setModulesData(modulesData.filter((module) => module.id !== id));
                    },
                },
            ]
        );
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Module List</Text>
            <FlatList
                data={modulesData}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <View style={styles.listItem}>
                        <Text style={styles.moduleCode}>{item.id}</Text>
                        <Text style={styles.moduleName}>{item.name}</Text>
                        <Text style={styles.moduleGrade}>
                            Grade: {item.grade} | Credits: {item.credit}
                        </Text>
                        <View style={styles.actionButtons}>
                            <TouchableOpacity
                                style={styles.editButton}
                                onPress={() =>
                                    navigation.navigate('Edit Module', {
                                        module: item,
                                        modulesData,
                                        setModulesData,
                                    })
                                }
                            >
                                <Text style={styles.buttonText}>Edit</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={styles.deleteButton}
                                onPress={() => deleteModule(item.id)}
                            >
                                <Text style={styles.buttonText}>Delete</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            />
            <View style={styles.buttonContainer}>
                <Button
                    title="Add New Module"
                    onPress={() =>
                        navigation.navigate('Add Module', { modulesData, setModulesData })
                    }
                />
                <Button
                    title="Calculate GPA"
                    onPress={() => {
                        const gpa = calculateGPA(modulesData);
                        navigation.navigate('GPA Calculator', { gpa });
                    }}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    listItem: {
        padding: 10,
        backgroundColor: '#fff',
        marginBottom: 10,
        borderRadius: 5,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 5,
        elevation: 3,
    },
    moduleCode: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    moduleName: {
        fontSize: 16,
        color: '#555',
    },
    moduleGrade: {
        fontSize: 14,
        color: '#777',
    },
    actionButtons: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
    },
    editButton: {
        backgroundColor: '#4caf50',
        padding: 8,
        borderRadius: 5,
        marginRight: 5,
    },
    deleteButton: {
        backgroundColor: '#f44336',
        padding: 8,
        borderRadius: 5,
    },
    buttonText: {
        color: '#fff',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    buttonContainer: {
        marginTop: 20,
    },
});



