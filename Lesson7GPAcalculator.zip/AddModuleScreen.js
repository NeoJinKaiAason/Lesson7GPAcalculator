import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function AddModuleScreen({ route, navigation }) {
    const { modulesData, setModulesData } = route.params;

    const [moduleCode, setModuleCode] = useState('');
    const [moduleName, setModuleName] = useState('');
    const [moduleGrade, setModuleGrade] = useState('');
    const [moduleCredit, setModuleCredit] = useState('');

    const addModule = () => {
        if (!moduleCode || !moduleName || !moduleGrade || !moduleCredit) {
            alert('Please fill in all fields.');
            return;
        }

        const newModule = {
            id: moduleCode,
            name: moduleName,
            grade: moduleGrade,
            credit: parseInt(moduleCredit, 10),
        };

        setModulesData([...modulesData, newModule]);
        navigation.goBack(); // Return to the HomeScreen
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Add New Module</Text>
            <TextInput
                style={styles.input}
                placeholder="Module Code"
                value={moduleCode}
                onChangeText={setModuleCode}
            />
            <TextInput
                style={styles.input}
                placeholder="Module Name"
                value={moduleName}
                onChangeText={setModuleName}
            />
            <TextInput
                style={styles.input}
                placeholder="Grade (e.g., A, B+, etc.)"
                value={moduleGrade}
                onChangeText={setModuleGrade}
            />
            <TextInput
                style={styles.input}
                placeholder="Credits"
                keyboardType="numeric"
                value={moduleCredit}
                onChangeText={setModuleCredit}
            />
            <Button title="Add Module" onPress={addModule} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        padding: 10,
        marginBottom: 15,
        backgroundColor: '#fff',
    },
});

