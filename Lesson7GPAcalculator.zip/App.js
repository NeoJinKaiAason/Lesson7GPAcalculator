import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from './HomeScreen';
import AddModuleScreen from './AddModuleScreen';
import EditModuleScreen from './EditModuleScreen';
import GPACalculatorScreen from './GPACalculatorScreen';

const Stack = createStackNavigator();

export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Home">
                <Stack.Screen name="Home" component={HomeScreen} />
                <Stack.Screen name="Add Module" component={AddModuleScreen} />
                <Stack.Screen name="Edit Module" component={EditModuleScreen} />
                <Stack.Screen name="GPA Calculator" component={GPACalculatorScreen} />
            </Stack.Navigator>
        </NavigationContainer>
    );
}




