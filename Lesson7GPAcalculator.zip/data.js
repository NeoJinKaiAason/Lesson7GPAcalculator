const modules = [
    {
        id: 'C218',
        name: 'UI/UX Design for Apps',
        description: 'Learn the principles of UI/UX design for creating user-friendly and effective apps.',
        credit: 4,
        grade: 'A', // Example grade
    },
    {
        id: 'C257',
        name: 'Fundamentals of Design',
        description: 'Understand the basics of design thinking and creative problem-solving.',
        credit: 4,
        grade: 'B',
    },
    {
        id: 'C339',
        name: 'Software Testing and Analytics',
        description: 'Master software testing methods and analytical tools.',
        credit: 6,
        grade: 'B+',
    },
    {
        id: 'C346',
        name: 'Mobile App Development',
        description: 'Develop mobile applications for Android and iOS using modern frameworks.',
        credit: 6,
        grade: 'A',
    },
    {
        id: 'C390',
        name: 'Portfolio Development',
        description: 'Create a professional portfolio to showcase your projects and skills.',
        credit: 4,
        grade: 'B+',
    },
];

export default modules;
